package br.fiap.endereco;

public class Endereco {

	private int id;
	private int cep;
	private String complemento;
	private int numero;

	public Endereco(int id, int cep, String complemento, int numero) {
		super();
		this.id = id;
		this.cep = cep;
		this.complemento = complemento;
		this.numero = numero;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCep() {
		return cep;
	}

	public void setCep(int cep) {
		this.cep = cep;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "ID: " + id + "\n";
		aux += "CEP: " + cep + "\n";
		aux += "Complemento: " + complemento + "\n";
		aux += "N�mero: " + numero;

		return aux;
	}

}
