package br.fiap.main;

import static javax.swing.JOptionPane.showMessageDialog;

import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.ServicoDAO;
import br.fiap.servico.Servico;

public class TesteConsulta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Consulta servi�o
		ServicoDAO dao = new ServicoDAO();
		// Recupera o servico com c�digo 1
		dao.pesquisar(1);

		// Consulta endere�o
		// EnderecoDAO dao = new EnderecoDAO();
		// Recupera o servico com c�digo 1
		// dao.pesquisar(1);

		// Consulta contato
		//ContatoDAO dao = new ContatoDAO();
		// Recupera o servico com c�digo 1
		//dao.pesquisar("teste7@outlook");

	}

}
