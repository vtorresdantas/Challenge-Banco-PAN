package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.endereco.Endereco;
import br.fiap.servico.Servico;

import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class ServicoDAO {

	// vari�veis para manipula��o de dadosa
	private Connection connection; // armazena a conex�o com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL
	Servico servico;

	public ServicoDAO() {

		connection = new Conexao().conectar();

	}

	public void inserir(Servico servico) {

		sql = "INSERT INTO JAVA_SERVICO(ID_SERVICO, NOME, DESCRICAO) VALUES (?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, servico.getId());
			ps.setString(2, servico.getNome());
			ps.setString(3, servico.getDescricao());
			ps.execute();

			showMessageDialog(null, "Servi�o cadastrado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao inserir registro no banco de dados\n" + e);

		}
	}

	public void remover(int id) {

		sql = "DELETE FROM JAVA_SERVICO WHERE ID_SERVICO = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			showMessageDialog(null, "Servi�o removido");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public void atualizar(Servico servico) {

		sql = "UPDATE JAVA_SERVICO SET NOME = ?, DESCRICAO = ? WHERE ID_SERVICO = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setString(1, servico.getNome());
			ps.setString(2, servico.getDescricao());
			ps.setInt(3, servico.getId());
			ps.executeUpdate();
			
			showMessageDialog(null, "Servi�o atualizado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}

	}

	public Servico pesquisar(int id) {

		Servico servico = null;

		sql = "SELECT * FROM JAVA_SERVICO WHERE id_servico = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			if (rs.next()) {
				id = rs.getInt("ID_SERVICO");
				String nome = rs.getString("NOME");
				String descricao = rs.getString("DESCRICAO");
				servico = new Servico(id, nome, descricao);

			}

			showMessageDialog(null, servico.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return servico;
	}

	public List<Servico> listar() {

		List<Servico> lista = new ArrayList<Servico>();

		sql = "SELECT * FROM JAVA_SERVICO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_SERVICO");
				String nome = rs.getString("NOME");
				String descricao = rs.getString("DESCRICAO");

				// Cria um objeto Servico com as informa��es encontradas
				Servico servico = new Servico(id, nome, descricao);
				// Adiciona o Endereco na lista
				lista.add(servico);

			}

			for (Servico item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

}
