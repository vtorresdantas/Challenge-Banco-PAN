package br.fiap.main;

import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.ServicoDAO;

public class TesteRemocao {

	public static void main(String[] args) {

		// Remover objeto servi�o
		// instancia o objeto dao
		ServicoDAO dao = new ServicoDAO();
		// chamada do m�todos de remo��o
		dao.remover(2);

		// Remover objeto endere�o
		// instancia o objeto dao
		//EnderecoDAO dao = new EnderecoDAO();
		// chamada do m�todos de remo��o
		//dao.remover(2);

		// Remover objeto contato
		// instancia o objeto dao
		//ContatoDAO dao = new ContatoDAO();
		// chamada do m�todos de remo��o
		//dao.remover(2);
	}

}
