package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.contato.Contato;
import br.fiap.endereco.Endereco;

public class ContatoDAO {

	// vari�veis para manipula��o de dadosa
	private Connection connection; // armazena a conex�o com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public ContatoDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Contato contato) {

		sql = "INSERT INTO JAVA_CONTATO(id_contato, telefone, email) VALUES (?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, contato.getId());
			ps.setInt(2, contato.getTelefone());
			ps.setString(3, contato.getEmail());
			ps.execute();

			showMessageDialog(null, "Contato cadastrado");

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao inserir no banco de dados\n" + e);

		}
	}

	public void remover(int id) {

		sql = "DELETE FROM JAVA_CONTATO WHERE ID_CONTATO = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			showMessageDialog(null, "Contato removido");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public Contato pesquisar(String email) {

		Contato contato = null;

		sql = "SELECT * FROM JAVA_CONTATO WHERE email = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, email);
			rs = ps.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("ID_CONTATO");
				int telefone = rs.getInt("TELEFONE");
				email = rs.getString("EMAIL");

				contato = new Contato(id, telefone, email);

			}

			showMessageDialog(null, contato.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return contato;
	}

	public List<Contato> listar() {

		List<Contato> lista = new ArrayList<Contato>();

		sql = "SELECT * FROM JAVA_CONTATO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_CONTATO");
				int telefone = rs.getInt("TELEFONE");
				String email = rs.getString("EMAIL");

				// Cria um objeto Contato com as informa��es encontradas
				Contato contato = new Contato(id, telefone, email);
				// Adiciona o Contato na lista
				lista.add(contato);

			}

			for (Contato item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

	public void atualizar(Contato contato) {

		sql = "UPDATE JAVA_CONTATO SET TELEFONE = ?, EMAIL = ? WHERE ID_CONTATO = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setInt(1, contato.getTelefone());
			ps.setString(2, contato.getEmail());
			ps.setInt(3, contato.getId());
			ps.executeUpdate();

			showMessageDialog(null, "Contato atualizado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}

	}

}
