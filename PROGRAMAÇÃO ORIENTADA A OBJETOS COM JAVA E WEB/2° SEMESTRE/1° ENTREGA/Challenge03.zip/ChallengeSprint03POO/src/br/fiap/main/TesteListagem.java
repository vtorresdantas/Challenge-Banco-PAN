package br.fiap.main;

import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.ServicoDAO;

public class TesteListagem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Listagem servi�o
		ServicoDAO dao = new ServicoDAO();
		dao.listar();

		// Listagem endere�o
		// EnderecoDAO dao = new EnderecoDAO();
		// dao.listar();

		// Listagemcontato
		//ContatoDAO dao = new ContatoDAO();
		//dao.listar();

	}

}
