package br.fiap.contato;

public class Contato {

	private int id;
	private int telefone;
	private String email;

	public Contato(int id, int telefone, String email) {
		super();
		this.id = id;
		this.telefone = telefone;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "ID: " + id + "\n";
		aux += "Telefone: " + telefone + "\n";
		aux += "E-mail: " + email + "\n";

		return aux;
	}

}
