package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.endereco.*;
import br.fiap.servico.Servico;

public class EnderecoDAO {

	// vari�veis para manipula��o de dados
	private Connection connection; // armazena a conex�o com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public EnderecoDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Endereco endereco) {

		sql = "INSERT INTO JAVA_ENDERECO(id_endereco, cep, complemento, numero) VALUES (?,?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, endereco.getId());
			ps.setInt(2, endereco.getCep());
			ps.setString(3, endereco.getComplemento());
			ps.setInt(4, endereco.getNumero());
			ps.execute();

			showMessageDialog(null, "Endere�o cadastrado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao inserir no banco de dados\n" + e);

		}
	}

	public void remover(int id) {

		sql = "DELETE FROM JAVA_ENDERECO WHERE ID_ENDERECO = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

			showMessageDialog(null, "Endere�o removido");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public Endereco pesquisar(int id) {

		Endereco endereco = null;

		sql = "SELECT * FROM JAVA_ENDERECO WHERE id_endereco = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			if (rs.next()) {
				id = rs.getInt("ID_ENDERECO");
				int cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");
				endereco = new Endereco(id, cep, complemento, numero);

			}

			showMessageDialog(null, endereco.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return endereco;
	}

	public List<Endereco> listar() {

		List<Endereco> lista = new ArrayList<Endereco>();

		sql = "SELECT * FROM JAVA_ENDERECO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_ENDERECO");
				int cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");

				// Cria um objeto Endere�o com as informa��es encontradas
				Endereco endereco = new Endereco(id, cep, complemento, numero);
				// Adiciona o Endereco na lista
				lista.add(endereco);

			}

			for (Endereco item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

	public void atualizar(Endereco endereco) {

		sql = "UPDATE JAVA_ENDERECO SET CEP = ?, COMPLEMENTO = ?, NUMERO = ? WHERE ID_ENDERECO = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setInt(1, endereco.getCep());
			ps.setString(2, endereco.getComplemento());
			ps.setInt(3, endereco.getNumero());
			ps.setInt(4, endereco.getId());
			ps.executeUpdate();

			showMessageDialog(null, "Endere�o atualizado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}

	}

}
