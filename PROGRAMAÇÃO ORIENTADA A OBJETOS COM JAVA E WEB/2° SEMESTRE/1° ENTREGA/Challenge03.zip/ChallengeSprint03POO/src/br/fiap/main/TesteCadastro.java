package br.fiap.main;

import br.fiap.contato.Contato;
import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.ServicoDAO;
import br.fiap.endereco.Endereco;
import br.fiap.servico.Servico;

public class TesteCadastro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Cadastro endere�o
		// Instancia o DAO
		EnderecoDAO dao = new EnderecoDAO();
		// Instancia o objeto servico
		Endereco endereco = new Endereco(2, 10, "teste", 10);
		// Cadastra no banco de dados
		dao.inserir(endereco);

		// Cadastro contato
		// Instancia o DAO
		// ContatoDAO dao = new ContatoDAO();
		// Instancia o objeto servico
		// Contato contato = new Contato(2, 1011000, "teste7@outlook");
		// Cadastra no banco de dados
		// dao.inserir(contato);

		// Cadastro servi�o
		// Instancia o DAO
		// ServicoDAO dao = new ServicoDAO();
		// Instancia o objeto servico
		// Servico servico = new Servico(3, "teste", "teste");
		// Cadastra no banco de dados
		// dao.inserir(servico);

	}

}
