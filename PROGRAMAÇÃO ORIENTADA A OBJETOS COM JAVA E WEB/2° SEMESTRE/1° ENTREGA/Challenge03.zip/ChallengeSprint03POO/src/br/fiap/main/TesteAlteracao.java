package br.fiap.main;

import br.fiap.contato.Contato;
import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.ServicoDAO;
import br.fiap.endereco.Endereco;
import br.fiap.servico.Servico;

public class TesteAlteracao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Altera��o objeto servi�o
		// Recupera o servi�o com c�digo 1
		ServicoDAO dao = new ServicoDAO();
		// imprime os valores do colaborador
		Servico servico = dao.pesquisar(1);
		// Altera��o dos valores
		servico.setNome("teste2");
		servico.setDescricao("descricao2");
		// Atualiza no banco de dados
		dao.atualizar(servico);

		// altera��o objeto endere�o
		// Recupera o endere�o com c�digo 1
		// EnderecoDAO dao = new EnderecoDAO();
		// imprime os valores do colaborador
		// Endereco endereco = dao.pesquisar(1);
		// Altera��o dos valores
		// endereco.setCep(041);
		// endereco.setComplemento("Casa");
		// Atualiza no banco de dados
		// dao.atualizar(endereco);

		// altera��o objeto contato
		// Recupera o endere�o com c�digo 1
		//ContatoDAO dao = new ContatoDAO();
		// imprime os valores do colaborador
		//Contato contato = dao.pesquisar("teste7@outlook");
		// Altera��o dos valores
		//contato.setEmail("teste@gmail.com");
		//contato.setTelefone(40028922);
		// Atualiza no banco de dados
		//dao.atualizar(contato);

	}

}
