package br.fiap.com.teste;

import br.fiap.com.dao.ColaboradorDAO;

public class TesteRemocao {

	public static void main(String[] args) {
		ColaboradorDAO dao = new ColaboradorDAO();
		// Remove o colaborador com c�digo 1
		dao.remover(4);
	}

}