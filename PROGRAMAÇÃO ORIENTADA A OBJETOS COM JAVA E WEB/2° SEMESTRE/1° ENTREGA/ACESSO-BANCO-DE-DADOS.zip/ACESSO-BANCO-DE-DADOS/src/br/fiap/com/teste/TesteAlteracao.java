package br.fiap.com.teste;

import br.fiap.com.bean.Colaborador;
import br.fiap.com.dao.ColaboradorDAO;

public class TesteAlteracao {

	public static void main(String[] args) {

		ColaboradorDAO dao = new ColaboradorDAO();
		// Recupera o colaborador com c�digo 1
		Colaborador colaborador = dao.buscarPorID(1);
		// Imprime os valores do colaborador
		System.out.println(colaborador.getCodigo() + " " + colaborador.getNome() + " " + colaborador.getEmail() + " "
				+ colaborador.getSalario() + " " + colaborador.getDataContratacao().getTime());
		// Altera os valores de alguns atributos do colaborador
		colaborador.setSalario(1500);
		colaborador.setEmail("teste@fiap.com.br");
		// Atualiza no banco de dados
		dao.atualizar(colaborador);
	}

}