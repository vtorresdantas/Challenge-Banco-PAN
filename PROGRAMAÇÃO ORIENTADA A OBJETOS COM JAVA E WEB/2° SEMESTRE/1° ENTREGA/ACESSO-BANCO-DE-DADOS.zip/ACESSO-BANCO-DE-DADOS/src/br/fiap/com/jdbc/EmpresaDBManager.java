package br.fiap.com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class EmpresaDBManager {

	public static Connection obterConexao() {
		Connection conexao = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			conexao = DriverManager.getConnection("jdbc:oracle:thin:@192.168.15.123:1521/xe", "system", "Carmem@12");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conexao;
	}

}
