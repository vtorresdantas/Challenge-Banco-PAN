package br.fiap.com.teste;

import java.util.Calendar;

import br.fiap.com.bean.Colaborador;
import br.fiap.com.dao.ColaboradorDAO;

public class TesteCadastro {

	public static void main(String[] args) {
		// Instancia o DAO
		ColaboradorDAO dao = new ColaboradorDAO();

		// Instancia o Colaborador
		Colaborador colaborador = new Colaborador();
		colaborador.setNome("teste");
		colaborador.setEmail("teste@fiap.com.br");
		colaborador.setSalario(10000);
		colaborador.setDataContratacao(Calendar.getInstance());

		// Cadastra no banco de dados
		dao.cadastrar(colaborador);

		System.out.println("Cadastrado!");
	}

}