package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

public class TesteConsulta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Instancia o DAO
		EnderecoDAO dao = new EnderecoDAO();
		// Recupera o colaborador com c�digo 1
		Endereco endereco = dao.buscarPorID(21);
		// Imprime os valores do colaborador
		System.out.println(endereco.toString());

	}

}
