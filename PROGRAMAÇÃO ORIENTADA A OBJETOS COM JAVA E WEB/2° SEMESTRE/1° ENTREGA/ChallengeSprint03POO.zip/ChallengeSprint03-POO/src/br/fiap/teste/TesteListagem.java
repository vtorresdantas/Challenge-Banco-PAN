package br.fiap.teste;

import java.util.List;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;


public class TesteListagem {

	public static void main(String[] args) {

		EnderecoDAO dao = new EnderecoDAO();

		List<Endereco> lista = dao.listar();
		for (Endereco item : lista) {
			System.out.println(item.toString() + "\n");
		}
	}

}