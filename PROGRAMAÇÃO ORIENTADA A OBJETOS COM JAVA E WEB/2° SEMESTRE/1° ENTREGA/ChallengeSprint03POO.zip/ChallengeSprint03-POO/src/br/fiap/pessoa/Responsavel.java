package br.fiap.pessoa;

import java.util.Calendar;

import br.fiap.endereco.Endereco;

public class Responsavel extends Pessoa {

	private double salario;
	private Calendar dataContratacao;

	public Responsavel(int codigo, String nome, char sexo, Calendar dataNascimento, String cpf, Calendar dataCadastro,
			Endereco endereco, double salario, Calendar dataContratacao) {
		super(codigo, nome, sexo, dataNascimento, cpf, dataCadastro, endereco);
		this.salario = salario;
		this.dataContratacao = dataContratacao;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Calendar getDataContratacao() {
		return dataContratacao;
	}

	public void setDataContratacao(Calendar dataContratacao) {
		this.dataContratacao = dataContratacao;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "C�digo: " + codigo + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Sexo: " + sexo + "\n";
		aux += "Data de nascimento: " + dataNascimento + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Data de cadastro: " + dataCadastro + "\n";
		aux += "Informa��es do endere�o: " + endereco.toString() + "\n";
		aux += "Data de contrata��o: /n" + dataContratacao + "\n";
		aux += "Sal�rio R$: /n" + salario;

		return aux;
	}

}
