package br.fiap.servico;

public class Servico {

	private int codigo;
	private String nomeServico;
	private String descricao;

	public Servico(int codigo, String nomeServico, String descricao) {
		super();
		this.codigo = codigo;
		this.nomeServico = nomeServico;
		this.descricao = descricao;
	}

	public String getNomeServico() {
		return nomeServico;
	}

	public void setNomeServico(String nomeServico) {
		this.nomeServico = nomeServico;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "C�digo: " + codigo + "\n";
		aux += "Nome do servi�o: " + nomeServico + "\n";
		aux += "Descricao: " + descricao + "\n";

		return aux;
	}

}
