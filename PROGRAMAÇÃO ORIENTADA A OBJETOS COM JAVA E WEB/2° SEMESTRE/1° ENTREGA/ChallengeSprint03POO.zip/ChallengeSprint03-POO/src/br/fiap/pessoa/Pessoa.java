package br.fiap.pessoa;

import java.util.Calendar;

import br.fiap.endereco.Endereco;

public abstract class Pessoa {

	protected int codigo;
	protected String nome;
	protected char sexo;
	protected Calendar dataNascimento;
	protected String cpf;
	protected Calendar dataCadastro;
	protected Endereco endereco;

	public Pessoa(int codigo, String nome, char sexo, Calendar dataNascimento, String cpf, Calendar dataCadastro,
			Endereco endereco) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.cpf = cpf;
		this.dataCadastro = dataCadastro;
		this.endereco = endereco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public Calendar getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Calendar dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Calendar getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public int getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "C�digo: " + codigo + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Sexo: " + sexo + "\n";
		aux += "Data de nascimento: " + dataNascimento + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Data de cadastro: " + dataCadastro + "\n";
		aux += "Informa��es do endere�o: " + endereco.toString();

		return aux;
	}

}
