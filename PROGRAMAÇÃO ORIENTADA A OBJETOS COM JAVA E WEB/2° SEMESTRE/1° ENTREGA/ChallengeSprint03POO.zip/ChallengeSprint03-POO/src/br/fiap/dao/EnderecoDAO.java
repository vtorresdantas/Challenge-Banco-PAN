package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.fiap.endereco.Endereco;
import br.fiap.jdbc.ConexaoDBManager;

public class EnderecoDAO {

	private Connection conexao;

	public void cadastrar(Endereco endereco) {
		PreparedStatement stmt = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "INSERT INTO TAB_ENDERECO(CODIGO_ENDERECO, CEP, COMPLEMENTO, NUMERO) VALUES (SQ_Endereco.NEXTVAL, ?, ?, ?)";
			stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, endereco.getCep());
			stmt.setString(2, endereco.getComplemento());
			stmt.setInt(3, endereco.getNumero());

			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Endereco> listar() {

		// Cria uma lista de Enderecoes
		List<Endereco> lista = new ArrayList<Endereco>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_ENDERECO");
			rs = stmt.executeQuery();

			// Percorre todos os registros encontrados
			while (rs.next()) {
				int codigo = rs.getInt("CODIGO_ENDERECO");
				int cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");

				// Cria um objeto Endereco com as informa��es encontradas
				Endereco Endereco = new Endereco(codigo, cep, complemento, numero);
				// Adiciona o Endereco na lista
				lista.add(Endereco);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lista;
	}

	public void remover(int codigo) {
		PreparedStatement stmt = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "DELETE FROM TAB_Endereco WHERE CODIGO_ENDERECO = ?";
			stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, codigo);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Endereco buscarPorID(int codigo) {

		Endereco endereco = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_ENDERECO WHERE CODIGO_ENDERECO = ?");
			stmt.setInt(1, codigo);
			rs = stmt.executeQuery();

			if (rs.next()) {
				codigo = rs.getInt("CODIGO_ENDERECO");
				int cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");
				endereco = new Endereco(codigo, cep, complemento, numero);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return endereco;
	}

	public void atualizar(Endereco endereco) {
		PreparedStatement stmt = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "UPDATE TAB_ENDERECO SET CEP = ?, COMPLEMENTO = ?, NUMERO = ? WHERE CODIGO_ENDERECO = ?";
			stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, endereco.getCep());
			stmt.setString(2, endereco.getComplemento());
			stmt.setInt(3, endereco.getNumero());

			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
