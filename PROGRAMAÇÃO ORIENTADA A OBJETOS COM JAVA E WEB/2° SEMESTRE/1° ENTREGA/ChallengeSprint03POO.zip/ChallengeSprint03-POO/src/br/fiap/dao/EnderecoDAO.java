package br.fiap.dao;

import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.fiap.endereco.Endereco;
import br.fiap.jdbc.ConexaoDBManager;

public class EnderecoDAO {

	private Connection conexao;

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						cadastrar();
						break;
					case 2:

						break;
					case 3:

						break;
					case 4:

						break;
					case 5:

						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 6);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar endere�o\n";
		msg += "2. Editar endere�o\n";
		msg += "3. Consultar endere�o\n";
		msg += "4. Remover endere�o\n";
		msg += "5. Listar todos os endere�o\n";
		msg += "6. Sair";
		return msg;
	}

	public void cadastrar() {
		PreparedStatement stmt = null;

		// Cria uma lista de Endere�os
		List<Endereco> lista = new ArrayList<Endereco>();

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "INSERT INTO TAB_ENDERECO(CODIGO_ENDERECO, CEP, COMPLEMENTO, NUMERO) VALUES (SQ_Endereco.NEXTVAL, ?, ?, ?)";
			stmt = conexao.prepareStatement(sql);

			int cep = parseInt(showInputDialog("Digite o seu CEP:"));
			String complemento = showInputDialog("Digite o seu complemento");
			int numero = parseInt(showInputDialog("Digite o n�mero:"));

			Endereco enderecoDAO = new Endereco(cep, complemento, numero);
			lista.add(enderecoDAO);

			stmt.setInt(1, cep);
			stmt.setString(2, complemento);
			stmt.setInt(3, numero);

			stmt.executeUpdate();

			showMessageDialog(null, "Endere�o cadastrado");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Endereco> listar() {

		// Cria uma lista de Endere�os
		List<Endereco> lista = new ArrayList<Endereco>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_ENDERECO");
			rs = stmt.executeQuery();

			// Percorre todos os registros encontrados
			while (rs.next()) {

				int cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");

				// Cria um objeto Endereco com as informa��es encontradas
				Endereco Endereco = new Endereco(cep, complemento, numero);
				// Adiciona o Endereco na lista
				lista.add(Endereco);

				for (Endereco item : lista) {

					showMessageDialog(null, item.toString() + "\n");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lista;
	}

	public void remover() {
		PreparedStatement stmt = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "DELETE FROM TAB_Endereco WHERE CEP = ?";
			stmt = conexao.prepareStatement(sql);

			int cep = parseInt(showInputDialog("Digite o CEP a ser exclu�do:"));

			stmt.setInt(1, cep);
			stmt.executeUpdate();

			showMessageDialog(null, "Endere�o exclu�do");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Endereco buscarPorID() {

		Endereco endereco = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_ENDERECO WHERE CEP = ?");

			int cep = parseInt(showInputDialog("Digite o CEP a ser pesquisado:"));

			stmt.setInt(1, cep);
			rs = stmt.executeQuery();

			if (rs.next()) {

				cep = rs.getInt("CEP");
				String complemento = rs.getString("COMPLEMENTO");
				int numero = rs.getInt("NUMERO");
				endereco = new Endereco(cep, complemento, numero);
			}

			showMessageDialog(null, endereco.toString());

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return endereco;
	}

	public void atualizar() {

		Endereco endereco = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		buscarPorID();

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "UPDATE TAB_ENDERECO SET CEP = ?, COMPLEMENTO = ?, NUMERO = ? WHERE CODIGO_ENDERECO = ?";
			stmt = conexao.prepareStatement(sql);

			int cep = parseInt(showInputDialog("Digite o seu novo CEP: "));
			String complemento = showInputDialog("Digite o seu novo complemento: ");
			int numero = parseInt(showInputDialog("Digite o seu novo n�mero: "));

			stmt.setInt(1, cep);
			stmt.setString(2, complemento);
			stmt.setInt(3, numero);

			stmt.executeUpdate();

			showMessageDialog(null, "Endere�o atualizado");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
