package br.fiap.dao;

public class PropostaDAO {

}
