package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

public class TesteAlteracao {

	public static void main(String[] args) {

		EnderecoDAO dao = new EnderecoDAO();

		// Atualiza no banco de dados
		dao.atualizar();

	}

}