package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

public class TesteAlteracao {

	public static void main(String[] args) {

		EnderecoDAO dao = new EnderecoDAO();
		// Recupera o endereco com c�digo 1

		Endereco endereco = dao.buscarPorID(21);
		// Imprime os valores do endereco

		System.out.println(endereco.getCodigo() + " " + endereco.getCep() + " " + endereco.getComplemento() + " "
				+ endereco.getNumero());

		// Altera os valores de alguns atributos do endereco
		endereco.setCep(04174135);
		endereco.setNumero(304);

		// Atualiza no banco de dados
		dao.atualizar(endereco);

	}

}