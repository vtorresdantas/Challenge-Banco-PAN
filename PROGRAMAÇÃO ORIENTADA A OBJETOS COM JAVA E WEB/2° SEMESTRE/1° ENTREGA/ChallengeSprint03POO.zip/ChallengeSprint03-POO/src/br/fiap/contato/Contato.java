package br.fiap.contato;

import br.fiap.pessoa.Pessoa;

public class Contato {

	private int codigo;
	private String telefone;
	private String email;
	private Pessoa pessoa;

	public Contato(int codigo, String telefone, String email, Pessoa pessoa) {
		super();
		this.codigo = codigo;
		this.telefone = telefone;
		this.email = email;
		this.pessoa = pessoa;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public int getCodigo() {
		return codigo;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "C�digo: " + codigo + "\n";
		aux += "Telefone: " + telefone + "\n";
		aux += "E-mail: " + email + "\n";
		aux += "Dados: " + pessoa.toString() + "\n";

		return aux;
	}

}
