package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.fiap.endereco.Endereco;
import br.fiap.jdbc.ConexaoDBManager;
import br.fiap.pessoa.Cliente;

public class ClienteDAO {

}
