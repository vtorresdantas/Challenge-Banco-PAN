package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

public class TesteCadastro {

	public static void main(String[] args) {
		// Instancia o DAO
		EnderecoDAO dao = new EnderecoDAO();

		// Instancia o Endereco
		Endereco endereco = new Endereco();
		endereco.setCep(1500);
		endereco.setComplemento("favela2");
		endereco.setNumero(1000);

		// Cadastra no banco de dados
		dao.cadastrar(endereco);

		System.out.println("Cadastrado!");
	}

}