package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

public class TesteCadastro {

	public static void main(String[] args) {
		// Instancia o DAO
		EnderecoDAO dao = new EnderecoDAO();

		dao.menu();

	}

}