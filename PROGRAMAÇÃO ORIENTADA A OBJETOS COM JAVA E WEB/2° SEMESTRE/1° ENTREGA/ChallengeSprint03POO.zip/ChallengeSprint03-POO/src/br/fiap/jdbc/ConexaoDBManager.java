package br.fiap.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoDBManager {

	public static Connection obterConexao() {
		Connection conexao = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			conexao = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "system", "Carmem@12");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conexao;
	}

}
