package br.fiap.pessoa;

import java.util.Calendar;

import br.fiap.endereco.Endereco;

public class Cliente extends Pessoa {

	private long cadastro;

	public Cliente(int codigo, String nome, char sexo, Calendar dataNascimento, String cpf, Calendar dataCadastro,
			Endereco endereco, long cadastro) {
		super(codigo, nome, sexo, dataNascimento, cpf, dataCadastro, endereco);
		this.cadastro = cadastro;
	}

	public long getCadastro() {
		return cadastro;
	}

	public void setCadastro(long cadastro) {
		this.cadastro = cadastro;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "C�digo: " + codigo + "\n";
		aux += "Nome: " + nome + "\n";
		aux += "Sexo: " + sexo + "\n";
		aux += "Data de nascimento: " + dataNascimento + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Data de cadastro: " + dataCadastro + "\n";
		aux += "Informa��es do endere�o: " + endereco.toString() + "\n";
		aux += "Cadastro: " + cadastro + "\n";

		return aux;
	}

}
