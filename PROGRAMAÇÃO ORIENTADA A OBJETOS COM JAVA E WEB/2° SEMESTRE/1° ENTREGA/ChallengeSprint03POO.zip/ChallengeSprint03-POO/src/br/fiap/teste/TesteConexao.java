package br.fiap.teste;

import java.sql.Connection;
import java.sql.SQLException;

import br.fiap.jdbc.ConexaoDBManager;

public class TesteConexao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			// Abre uma conex�o
			Connection conexao = ConexaoDBManager.obterConexao();

			System.out.println("Conectado!");

			// Fecha a conex�o
			conexao.close();

			// Tratamento de erro
		} catch (SQLException e) {
			System.err.println("N�o foi poss�vel conectar no Banco de Dados");
			e.printStackTrace();
		}

	}

}
