package br.fiap.dao;

import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.fiap.servico.Servico;
import br.fiap.jdbc.ConexaoDBManager;

public class ServicoDAO {

	private Connection conexao;

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						cadastrar();
						break;
					case 2:
						atualizar();
						break;
					case 3:
						buscarPorID();
						break;
					case 4:
						remover();

						break;
					case 5:
						listar();

						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 6);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar servi�o\n";
		msg += "2. Editar servi�o\n";
		msg += "3. Consultar servi�o\n";
		msg += "4. Remover servi�o\n";
		msg += "5. Listar todos os servi�os\n";
		msg += "6. Sair";
		return msg;
	}

	public void cadastrar() {
		PreparedStatement stmt = null;

		// Cria uma lista de Endere�os
		List<Servico> lista = new ArrayList<Servico>();

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "INSERT INTO TAB_SERVICO(CODIGO_SERVICO, NOME, DESCRICAO) VALUES (SQ_Servico.NEXTVAL, ?, ?)";
			stmt = conexao.prepareStatement(sql);

			String nome = showInputDialog("Digite o nome do servi�o");
			String descricao = showInputDialog("Digite a descri��o");

			Servico ServicoDAO = new Servico(nome, descricao);
			lista.add(ServicoDAO);

			stmt.setString(1, nome);
			stmt.setString(2, descricao);

			stmt.executeUpdate();

			showMessageDialog(null, "Servi�o cadastrado");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Servico> listar() {

		// Cria uma lista de Endere�os
		List<Servico> lista = new ArrayList<Servico>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_SERVICO");
			rs = stmt.executeQuery();

			// Percorre todos os registros encontrados
			while (rs.next()) {

				String nome = rs.getString("NOME");
				String descricao = rs.getString("DESCRI��O");

				// Cria um objeto Servico com as informa��es encontradas
				Servico servico = new Servico(nome, descricao);
				// Adiciona o Servico na lista
				lista.add(servico);

				for (Servico item : lista) {

					showMessageDialog(null, item.toString() + "\n");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return lista;
	}

	public void remover() {
		PreparedStatement stmt = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "DELETE FROM TAB_SERVICO WHERE NOME = ?";
			stmt = conexao.prepareStatement(sql);

			String nome = showInputDialog("Digite o nome do servi�o a ser exclu�do:");

			stmt.setString(1, nome);
			stmt.executeUpdate();

			showMessageDialog(null, "Servi�o exclu�do");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Servico buscarPorID() {

		Servico servico = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_SERVICO WHERE NOME = ?");

			String nome = showInputDialog("Digite o nome do servi�o a ser pesquisado:");

			stmt.setString(1, nome);
			rs = stmt.executeQuery();

			if (rs.next()) {

				nome = rs.getString("NOME");
				String descricao = rs.getString("DESCRI��O");
				servico = new Servico(nome, descricao);
			}

			showMessageDialog(null, servico.toString());

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return servico;
	}

	public void atualizar() {

		Servico servico = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "UPDATE TAB_SERVICO SET CEP = ?, COMPLEMENTO = ?, NUMERO = ? WHERE CODIGO_SERVICO = ?";
			stmt = conexao.prepareStatement(sql);

			int cep = parseInt(showInputDialog("Digite o seu novo CEP: "));
			String complemento = showInputDialog("Digite o seu novo complemento: ");
			int numero = parseInt(showInputDialog("Digite o seu novo n�mero: "));

			stmt.setInt(1, cep);
			stmt.setString(2, complemento);
			stmt.setInt(3, numero);

			stmt.executeUpdate();

			showMessageDialog(null, "Endere�o atualizado");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
