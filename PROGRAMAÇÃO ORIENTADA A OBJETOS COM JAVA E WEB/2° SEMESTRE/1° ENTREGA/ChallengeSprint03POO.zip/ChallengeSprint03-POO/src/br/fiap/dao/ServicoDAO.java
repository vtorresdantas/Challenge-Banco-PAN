package br.fiap.dao;

public class ServicoDAO {

}
