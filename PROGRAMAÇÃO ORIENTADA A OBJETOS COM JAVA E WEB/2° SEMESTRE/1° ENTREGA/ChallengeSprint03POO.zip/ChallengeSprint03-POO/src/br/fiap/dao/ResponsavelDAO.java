package br.fiap.dao;

public class ResponsavelDAO {

}
