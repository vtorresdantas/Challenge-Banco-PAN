package br.fiap.dao;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;

public class ResponsavelDAO {
	
	private Connection conexao;

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
					
						break;
					case 2:
						

						break;
					case 3:
						

						break;
					case 4:
						

						break;
					case 5:
						

						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 6);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar respons�vel\n";
		msg += "2. Editar respons�vel\n";
		msg += "3. Consultar respons�vel\n";
		msg += "4. Remover respons�vel\n";
		msg += "5. Listar todos os respons�veis\n";
		msg += "6. Sair";
		return msg;
	}

}
