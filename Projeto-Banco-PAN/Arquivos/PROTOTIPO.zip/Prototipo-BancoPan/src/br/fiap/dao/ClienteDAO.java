package br.fiap.dao;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import br.fiap.endereco.Endereco;
import br.fiap.jdbc.ConexaoDBManager;
import br.fiap.pessoa.Cliente;
import br.fiap.pessoa.Pessoa;
import br.fiap.servico.Servico;

public class ClienteDAO {

	private Connection conexao;

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						cadastrar();
						break;
					case 2:

						break;
					case 3:
						buscarPorID();

						break;
					case 4:

						break;
					case 5:

						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 6);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar cliente\n";
		msg += "2. Editar cliente\n";
		msg += "3. Consultar cliente\n";
		msg += "4. Remover cliente\n";
		msg += "5. Listar todos os cliente\n";
		msg += "6. Sair";
		return msg;
	}

	public void cadastrar() {
		PreparedStatement stmt = null;

		// Cria uma lista de Endere�os
		List<Cliente> lista = new ArrayList<Cliente>();

		try {
			conexao = ConexaoDBManager.obterConexao();
			String sql = "INSERT INTO TAB_CLIENTE(CODIGO_CLIENTE, NOME, SEXO, DATA_NASCIMENTO, CPF, DATA_CADASTRO, CADASTRO) VALUES (SQ_Servico.NEXTVAL, ?, ?, ?, ?, ?, ?)";
			stmt = conexao.prepareStatement(sql);

			String endereco = null;
			String nome = showInputDialog("Digite seu nome");
			String sexo = showInputDialog("Digite o seu sexo");
			String dataNascimento = showInputDialog("Digite a sua data de nascimento");
			String cpf = showInputDialog("Digite o seu cpf");
			String dataCadastro = showInputDialog("Digite a data de cadastro");
			int cadastro = parseInt(showInputDialog("Digite o seu n�mero de cadastro: "));

			Cliente clienteDAO = new Cliente(nome, sexo, dataNascimento, cpf, dataCadastro, cadastro);
			lista.add(clienteDAO);

			stmt.setString(1, nome);
			stmt.setString(2, sexo);
			stmt.setString(3, dataNascimento);
			stmt.setString(4, cpf);
			stmt.setString(5, dataCadastro);
			stmt.setInt(6, cadastro);

			stmt.executeUpdate();

			showMessageDialog(null, "Cliente cadastrado");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Cliente buscarPorID() {

		Cliente cliente = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conexao = ConexaoDBManager.obterConexao();
			stmt = conexao.prepareStatement("SELECT * FROM TAB_CLIENTE WHERE NOME = ?");

			String cpf = showInputDialog("Digite o cpf a ser pesquisado:");

			stmt.setString(1, cpf);
			rs = stmt.executeQuery();

			if (rs.next()) {

				String nome = rs.getString("NOME");
				String sexo = rs.getString("SEXO");
				String dataNascimento = rs.getString("DATA DE NASCIMENTO");
				cpf = rs.getString("CPF");
				String dataCadastro = rs.getString("DATA DE CADASTRO");
				int cadastro = rs.getInt("CADASTRO");
				cliente = new Cliente(nome, sexo, dataNascimento, cpf, dataCadastro, cadastro);
			}

			showMessageDialog(null, cliente.toString());

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				rs.close();
				conexao.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cliente;
	}

}
