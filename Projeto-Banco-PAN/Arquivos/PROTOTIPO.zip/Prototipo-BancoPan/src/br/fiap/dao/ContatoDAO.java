package br.fiap.dao;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.endereco.Endereco;
import br.fiap.jdbc.ConexaoDBManager;

public class ContatoDAO {

	private Connection conexao;
	
	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
					
						break;
					case 2:
						

						break;
					case 3:
						

						break;
					case 4:
						

						break;
					case 5:
						

						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 6);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar contato\n";
		msg += "2. Editar contato\n";
		msg += "3. Consultar contato\n";
		msg += "4. Remover contato\n";
		msg += "5. Listar todos os contatos\n";
		msg += "6. Sair";
		return msg;
	}

}
