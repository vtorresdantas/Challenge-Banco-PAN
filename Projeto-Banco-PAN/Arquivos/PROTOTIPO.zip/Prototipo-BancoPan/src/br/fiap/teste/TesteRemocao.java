package br.fiap.teste;

import br.fiap.dao.EnderecoDAO;

public class TesteRemocao {

	public static void main(String[] args) {
		EnderecoDAO dao = new EnderecoDAO();
		dao.remover();
	}

}