package br.fiap.proposta;

import br.fiap.pessoa.Cliente;
import br.fiap.pessoa.Responsavel;
import br.fiap.servico.Servico;

public class Proposta {

	private Responsavel responsavel;
	private Cliente cliente;
	private Servico servico;
	private boolean propostaAceita;
	private boolean propostaAnalisada;

	public Proposta(Responsavel responsavel, Cliente cliente, Servico servico, boolean propostaAceita,
			boolean propostaAnalisada) {
		super();

		this.responsavel = responsavel;
		this.cliente = cliente;
		this.servico = servico;
		this.propostaAceita = propostaAceita;
		this.propostaAnalisada = propostaAnalisada;
	}

	public Responsavel getResponsavel() {
		return responsavel;
	}

	public void setResponsavel(Responsavel responsavel) {
		this.responsavel = responsavel;
	}

	public Servico getServico() {
		return servico;
	}

	public void setServico(Servico servico) {
		this.servico = servico;
	}

	public boolean isPropostaAceita() {
		return propostaAceita;
	}

	public void setPropostaAceita(boolean propostaAceita) {
		this.propostaAceita = propostaAceita;
	}

	public boolean isPropostaAnalisada() {
		return propostaAnalisada;
	}

	public void setPropostaAnalisada(boolean propostaAnalisada) {
		this.propostaAnalisada = propostaAnalisada;
	}

	public Cliente getCliente() {
		return cliente;
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "Dados do respons�vel: " + responsavel + "\n";
		aux += "Dados do cliente: " + cliente + "\n";
		aux += "Dados do servi�o: " + servico + "\n";
		aux += "Proposta aceita: " + propostaAceita + "\n";
		aux += "Proposta analisada: " + propostaAnalisada;

		return aux;

	}

}
