package br.fiap.controle;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import br.fiap.dao.ClienteDAO;
import br.fiap.dao.ContatoDAO;
import br.fiap.dao.EnderecoDAO;
import br.fiap.dao.PropostaDAO;
import br.fiap.dao.ResponsavelDAO;
import br.fiap.dao.ServicoDAO;

public class Controle {

	ClienteDAO cliente = new ClienteDAO();
	ContatoDAO contato = new ContatoDAO();
	EnderecoDAO endereco = new EnderecoDAO();
	PropostaDAO proposta = new PropostaDAO();
	ServicoDAO servico = new ServicoDAO();
	ResponsavelDAO responsavel = new ResponsavelDAO();

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 3) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						menuCliente();
						break;
					case 2:
						menuResponsavel();
						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 3);
	}

	private String gerarMenu() {
		String msg = "Escolha uma op��o\n";
		msg += "1. Menu do cliente\n";
		msg += "2. Menu respons�vel\n";
		msg += "3. Finalizar";
		return msg;
	}

	public void menuCliente() {

		String msg = "Escolha uma op��o\n";
		msg += "1. Cadastrar novo cliente\n";
		msg += "2. Editar dados do cliente\n";
		msg += "3. Consultar dados do cliente\n";
		msg += "4. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 4) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						cliente.cadastrar();
						break;
					case 2:
						menuEditorCliente();
						break;
					case 3:
						cliente.buscarPorID();
						break;

					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 4);

	}

	public void menuEditorCliente() {

		String msg = "Escolha uma op��o\n";
		msg += "1. Editar dados do cliente\n";
		msg += "2. Acessar menu contato\n";
		msg += "3. Acessar menu endere�o\n";
		msg += "4. Acessar menu servi�os\n";
		msg += "5. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 4) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:

						break;
					case 2:

						break;
					case 3:
						endereco.menu();

						break;
					case 4:
						servico.menu();

						break;

					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 5);

	}

	public void menuResponsavel() {

		String msg = "Escolha uma op��o\n";
		msg += "1. Acesso menu do cliente\n";
		msg += "2. Acesso menu endere�o\n";
		msg += "3. Acesso menu contato\n";
		msg += "4. Acesso menu servi�os\n";
		msg += "5. Acesso menu propostas\n";
		msg += "6. Acesso menu respons�vel\n";
		msg += "7. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 7) {
					showMessageDialog(null, "Op��o inv�lida");
				} else {
					switch (opcao) {
					case 1:
						cliente.menu();
						break;
					case 2:
						endereco.menu();
						break;
					case 3:
						contato.menu();
						break;
					case 4:
						servico.menu();
						break;
					case 5:
						proposta.menu();
						break;
					case 6:
						responsavel.menu();
						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A op��o deve ser um n�mero v�lido");
			}
		} while (opcao != 7);

	}

}
