package br.fiap.pessoa;

import java.util.Calendar;

import br.fiap.endereco.Endereco;

public class Responsavel extends Pessoa {

	private double salario;
	private Calendar dataContratacao;

	public Responsavel(String nome, String sexo, String dataNascimento, String cpf, String dataCadastro,
			Endereco endereco, double salario, Calendar dataContratacao) {
		super(nome, sexo, dataNascimento, cpf, dataCadastro, endereco);
		this.salario = salario;
		this.dataContratacao = dataContratacao;
	}

	public Responsavel(String nome, String sexo, String dataNascimento, String cpf, String dataCadastro, double salario,
			Calendar dataContratacao) {
		super(nome, sexo, dataNascimento, cpf, dataCadastro);
		this.salario = salario;
		this.dataContratacao = dataContratacao;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Calendar getDataContratacao() {
		return dataContratacao;
	}

	public void setDataContratacao(Calendar dataContratacao) {
		this.dataContratacao = dataContratacao;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "Nome: " + nome + "\n";
		aux += "Sexo: " + sexo + "\n";
		aux += "Data de nascimento: " + dataNascimento + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Data de cadastro: " + dataCadastro + "\n";
		aux += "Data de contrata��o: /n" + dataContratacao + "\n";
		aux += "Sal�rio R$: /n" + salario;

		return aux;
	}

}
