package br.fiap.pessoa;

import java.util.Calendar;

import br.fiap.endereco.Endereco;

public class Cliente extends Pessoa {

	private int cadastro;

	public Cliente(String nome, String sexo, String dataNascimento, String cpf, String dataCadastro, Endereco endereco,
			int cadastro) {
		super(nome, sexo, dataNascimento, cpf, dataCadastro, endereco);
		this.cadastro = cadastro;
	}

	public Cliente(String nome, String sexo, String dataNascimento, String cpf, String dataCadastro, int cadastro) {
		super(nome, sexo, dataNascimento, cpf, dataCadastro);
		this.cadastro = cadastro;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "Nome: " + nome + "\n";
		aux += "Sexo: " + sexo + "\n";
		aux += "Data de nascimento: " + dataNascimento + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Data de cadastro: " + dataCadastro + "\n";
		aux += "Cadastro: " + cadastro + "\n";

		return aux;
	}

}
